

	Thank you for downloading this font!
	This product is 100% free for personal & commercial use.

      Guti is free to use under the Creative Commons Attribution-No Derivatives 4.0 International licence, 
      which means you may share, copy and redistribute the material in any medium or form for any purpose, 
      including commercial.

	Font Styles : 

	-Guti Bold
	-Guti Sembibold
	-Guti Regular
	-Guti Light
	-Guti Thin


	More Info : 
	itspaugs@gmail.com


	Follow me:

	https://www.liinks.co/paudesigns


	My Portofolio:
	https://www.behance.net/paugutirrez8

	© Copyright 2022 Pau Gutiérrez

